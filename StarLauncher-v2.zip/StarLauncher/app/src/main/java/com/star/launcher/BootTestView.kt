package com.star.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Animação de "teste de multitarefa" ao abrir o launcher.
 * É 100% visual (fake): uma única View desenhada em Canvas, sem imagens, sem alocação no onDraw.
 */
class BootTestView(
    ctx: Context,
    private val onReveal: () -> Unit,
    private val onDone: () -> Unit
) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val sp = d * resources.configuration.fontScale
    private val colors = intArrayOf(
        0xFF34C759.toInt(), 0xFF0A84FF.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF453A.toInt(),
        0xFFBF5AF2.toInt(), 0xFF64D2FF.toInt(), 0xFFFFD60A.toInt(), 0xFF30D158.toInt(),
        0xFFFF375F.toInt(), 0xFF5E5CE6.toInt(), 0xFF40C8E0.toInt(), 0xFFAC8E68.toInt()
    )
    private val n = colors.size
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private var t = 0f
    private var anim: ValueAnimator? = null
    private var ended = false
    private val score = 9200 + Random.nextInt(700) // pontuação falsa, só visual

    init {
        setOnClickListener { skip() } // toque = pular
    }

    fun start() {
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 4300
            interpolator = LinearInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    postDelayed({ finish() }, 450)
                }
            })
            start()
        }
    }

    private fun skip() {
        anim?.removeAllListeners()
        anim?.cancel()
        finish()
    }

    private fun finish() {
        if (ended) return
        ended = true
        onReveal()
        animate().alpha(0f).setDuration(450).withEndAction { onDone() }.start()
    }

    override fun onDetachedFromWindow() {
        anim?.removeAllListeners()
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun blend(a: Int, b: Int, p: Float): Int {
        val q = 1f - p
        return Color.rgb(
            (Color.red(a) * q + Color.red(b) * p).toInt(),
            (Color.green(a) * q + Color.green(b) * p).toInt(),
            (Color.blue(a) * q + Color.blue(b) * p).toInt()
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF000000.toInt())

        text.color = Color.WHITE
        text.textSize = 24f * sp
        text.isFakeBoldText = true
        c.drawText("Teste de desempenho", w / 2f, h * 0.13f, text)
        text.isFakeBoldText = false
        text.color = 0xFF8E8E93.toInt()
        text.textSize = 14f * sp
        c.drawText("Abrindo vários apps ao mesmo tempo…", w / 2f, h * 0.13f + 28f * d, text)

        val cols = 3
        val gridW = w * 0.74f
        val cell = gridW / cols
        val icon = cell * 0.66f
        val sx = (w - gridW) / 2f
        val sy = h * 0.22f
        var opened = 0

        for (i in 0 until n) {
            val p = ((t - 0.04f - i * 0.065f) / 0.13f).coerceIn(0f, 1f)
            if (p >= 1f) opened++
            val cx = sx + cell * (i % cols + 0.5f)
            val cy = sy + cell * (i / cols + 0.5f)
            val half = icon * (1f + 0.14f * sin(p * PI.toFloat())) / 2f

            paint.style = Paint.Style.FILL
            paint.color = blend(0xFF2C2C2E.toInt(), colors[i], p)
            rect.set(cx - half, cy - half, cx + half, cy + half)
            c.drawRoundRect(rect, half * 0.45f, half * 0.45f, paint)

            if (p > 0f) {
                paint.color = Color.WHITE
                paint.alpha = (200f * p).toInt()
                c.drawCircle(cx, cy, icon * 0.15f * p, paint)
            }
            if (p > 0f && p < 1f) {
                val g = half + 6f * d * p
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f * d
                paint.color = Color.WHITE
                paint.alpha = (255f * (1f - p)).toInt()
                rect.set(cx - g, cy - g, cx + g, cy + g)
                c.drawRoundRect(rect, g * 0.45f, g * 0.45f, paint)
                paint.style = Paint.Style.FILL
            }
        }

        val ease = 1f - (1f - t) * (1f - t) * (1f - t)
        text.color = 0xFF8E8E93.toInt()
        text.textSize = 15f * sp
        c.drawText("Apps abertos  $opened/$n", w / 2f, h * 0.72f, text)

        val bw = w * 0.7f
        val bh = 6f * d
        val bx = (w - bw) / 2f
        val by = h * 0.755f
        paint.style = Paint.Style.FILL
        paint.color = 0x33FFFFFF
        rect.set(bx, by, bx + bw, by + bh)
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint)
        paint.color = Color.WHITE
        rect.set(bx, by, bx + bw * t, by + bh)
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint)

        text.color = Color.WHITE
        text.textSize = 40f * sp
        text.isFakeBoldText = true
        c.drawText("${(score * ease).toInt()}", w / 2f, h * 0.84f, text)
        text.isFakeBoldText = false
        text.color = 0xFF8E8E93.toInt()
        text.textSize = 13f * sp
        c.drawText("pontuação multitarefa", w / 2f, h * 0.84f + 24f * d, text)

        if (t >= 1f) {
            text.color = 0xFF30D158.toInt()
            text.textSize = 16f * sp
            c.drawText("✓ Desempenho excelente", w / 2f, h * 0.92f, text)
        }
    }
}
