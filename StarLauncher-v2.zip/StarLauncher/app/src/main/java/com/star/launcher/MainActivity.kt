package com.star.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class AppInfo(val label: String, val pkg: String, val intent: Intent, val icon: Bitmap)

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    companion object {
        // A animação só roda quando o processo inicia (não toda vez que você aperta Home)
        private var bootShown = false
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var audio: AudioManager
    private lateinit var root: FrameLayout
    private lateinit var home: FrameLayout
    private lateinit var pager: SnapPager
    private lateinit var pagesRow: LinearLayout
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var dockBg: GradientDrawable
    private lateinit var hud: VolumeHud

    private var apps: List<AppInfo>? = null
    private var dockApps: List<AppInfo> = emptyList()
    private var insetTop = 0
    private var insetBottom = 0
    private var dockAlpha = 0.28f
    private var settingsView: View? = null
    private var menuView: View? = null
    private var bootView: BootTestView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    // Tamanho do ícone proporcional à largura da tela (igual ao iPhone: 60/390)
    private fun iconPx() = (resources.displayMetrics.widthPixels * 0.152f).toInt()

    // ------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("star", MODE_PRIVATE)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        dockAlpha = prefs.getFloat("dockAlpha", 0.28f)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        loadApps() // em thread separada, enquanto a animação roda

        if (!bootShown && prefs.getBoolean("boot", true)) runBoot() else bootShown = true
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            loadApps()
        }
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(pkgReceiver, f)
    }

    override fun onStop() {
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        super.onStop()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (bootView == null) {
            hideMenu()
            hideSettings()
            pager.smoothScrollTo(0, 0)
        }
    }

    override fun onBackPressed() {
        if (menuView != null) hideMenu() else if (settingsView != null) hideSettings()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            try {
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    0
                )
            } catch (e: Exception) {
            }
            showVolume()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------ UI

    private fun buildUi() {
        root = FrameLayout(this)
        setContentView(root)
        val sw = resources.displayMetrics.widthPixels

        home = FrameLayout(this)
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))

        pagesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pager = SnapPager(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(pagesRow, FrameLayout.LayoutParams(WRAP, MATCH))
        }
        home.addView(pager, FrameLayout.LayoutParams(MATCH, dp(300)).apply { gravity = Gravity.TOP })

        dots = DotsView(this)
        pager.onScrollPos = { dots.pos = it }
        home.addView(dots, FrameLayout.LayoutParams(MATCH, dp(24)).apply { gravity = Gravity.BOTTOM })

        dockBg = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = iconPx() * 0.52f
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = dockBg
        }
        home.addView(
            dock,
            FrameLayout.LayoutParams(MATCH, (iconPx() * 1.5f).toInt()).apply {
                gravity = Gravity.BOTTOM
                leftMargin = (sw * 0.025f).toInt()
                rightMargin = (sw * 0.025f).toInt()
            }
        )

        // Faixa na borda esquerda: arrastar para a direita abre o painel de volume
        val strip = View(this)
        var downX = 0f
        var opened = false
        strip.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    opened = false
                }
                MotionEvent.ACTION_MOVE -> if (!opened && e.rawX - downX > dp(24)) {
                    opened = true
                    showVolume()
                }
            }
            true
        }
        root.addView(
            strip,
            FrameLayout.LayoutParams(dp(20), dp(280)).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        )

        // Painel de volume estilo iOS (esquerda, pílula fina)
        hud = VolumeHud(this).apply {
            visibility = View.GONE
            onChange = { p ->
                setVolume(p)
                scheduleHideVolume()
            }
        }
        root.addView(
            hud,
            FrameLayout.LayoutParams((sw * 0.11f).toInt(), (sw * 0.44f).toInt()).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                leftMargin = (sw * 0.035f).toInt()
            }
        )

        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = ins.systemWindowInsetTop
            val b = ins.systemWindowInsetBottom
            if (t != insetTop || b != insetBottom) {
                insetTop = t
                insetBottom = b
                relayout()
            }
            ins
        }
        root.requestApplyInsets()
    }

    private fun applyAlpha() {
        dockBg.alpha = (dockAlpha * 255f).roundToInt()
    }

    // ------------------------------------------------------------ apps

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val px = iconPx()
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val cn = ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                    val launch = Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(cn)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, launch, IconStyler.render(it.loadIcon(pm), px))
                }
                .sortedBy { it.label.lowercase() }
            val dockList = resolveDock(pm, px)
            runOnUiThread {
                apps = list
                dockApps = dockList
                relayout()
            }
        }.start()
    }

    private fun resolveDock(pm: PackageManager, px: Int): List<AppInfo> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val out = ArrayList<AppInfo>()
        val seen = HashSet<String>()
        for (i in intents) {
            val def = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.takeIf { it.activityInfo.packageName != "android" && it.activityInfo.packageName != packageName }
            val ri = def ?: pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
                .firstOrNull { it.activityInfo.packageName != "android" && it.activityInfo.packageName != packageName }
                ?: continue
            if (!seen.add(ri.activityInfo.packageName)) continue
            val launch = Intent(i)
                .setComponent(ComponentName(ri.activityInfo.packageName, ri.activityInfo.name))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            out.add(AppInfo(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, launch, IconStyler.render(ri.loadIcon(pm), px)))
        }
        return out
    }

    private fun relayout() {
        val list = apps ?: return
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val icon = iconPx()
        val pitch = (icon * 1.58f).toInt()
        val dockH = (icon * 1.5f).toInt()
        val dockBottom = insetBottom + dp(6)
        val dotsH = dp(24)
        val top = insetTop + (icon * 0.32f).toInt()
        val avail = sh - top - dockH - dockBottom - dotsH - (icon * 0.2f).toInt()
        val cols = 4
        val rows = (avail / pitch).coerceIn(3, 6)
        val cellH = min(pitch * 1.2f, avail / rows.toFloat()).toInt()
        val per = cols * rows
        val pageCount = max(1, ceil(list.size / per.toFloat()).toInt())

        pagesRow.removeAllViews()
        for (p in 0 until pageCount) {
            val page = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setOnLongClickListener {
                    showSettings()
                    true
                }
            }
            for (r in 0 until rows) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (c in 0 until cols) {
                    val idx = p * per + r * cols + c
                    val v = if (idx < list.size) makeCell(list[idx], icon) else View(this)
                    row.addView(v, LinearLayout.LayoutParams(0, MATCH, 1f))
                }
                page.addView(row, LinearLayout.LayoutParams(MATCH, cellH))
            }
            pagesRow.addView(page, LinearLayout.LayoutParams(sw, rows * cellH))
        }

        (pager.layoutParams as FrameLayout.LayoutParams).let {
            it.topMargin = top
            it.height = rows * cellH
            pager.layoutParams = it
        }
        dots.count = pageCount
        (dots.layoutParams as FrameLayout.LayoutParams).let {
            it.bottomMargin = dockBottom + dockH + dp(4)
            dots.layoutParams = it
        }
        (dock.layoutParams as FrameLayout.LayoutParams).let {
            it.bottomMargin = dockBottom
            it.height = dockH
            dock.layoutParams = it
        }
        dock.removeAllViews()
        for (a in dockApps) dock.addView(makeDockIcon(a, icon), LinearLayout.LayoutParams(0, MATCH, 1f))
        applyAlpha()
    }

    private fun pressFeedback(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun makeIcon(app: AppInfo): ImageView = ImageView(this).apply {
        setImageBitmap(app.icon)
        scaleType = ImageView.ScaleType.FIT_XY
    }

    private fun makeCell(app: AppInfo, icon: Int): View {
        val iv = makeIcon(app)
        val label = TextView(this).apply {
            text = app.label
            setTextSize(TypedValue.COMPLEX_UNIT_PX, icon * 0.19f)
            setTextColor(Color.WHITE)
            setShadowLayer(3f, 0f, 1f, 0x66000000)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(2), 0, dp(2), 0)
            addView(iv, LinearLayout.LayoutParams(icon, icon))
            addView(label, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = (icon * 0.09f).toInt() })
            setOnClickListener { launch(app, iv) }
            setOnLongClickListener {
                showAppMenu(app, iv)
                true
            }
        }
        pressFeedback(col)
        return col
    }

    private fun makeDockIcon(app: AppInfo, icon: Int): View {
        val box = FrameLayout(this)
        val iv = makeIcon(app)
        box.addView(iv, FrameLayout.LayoutParams(icon, icon, Gravity.CENTER))
        box.setOnClickListener { launch(app, iv) }
        pressFeedback(box)
        return box
    }

    private fun launch(app: AppInfo, v: View) {
        try {
            val o = ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height)
            startActivity(app.intent, o.toBundle())
        } catch (e: Exception) {
            try {
                startActivity(app.intent)
            } catch (e2: Exception) {
            }
        }
    }

    // ------------------------------------------------------------ menu de contexto (estilo iOS)

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun menuRow(card: LinearLayout, label: String, color: Int, last: Boolean, action: () -> Unit) {
        val t = tv(label, 16f, color).apply {
            setPadding(dp(18), dp(13), dp(18), dp(13))
            setOnClickListener {
                hideMenu()
                action()
            }
        }
        card.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))
        if (!last) {
            card.addView(View(this).apply { setBackgroundColor(0x33FFFFFF) }, LinearLayout.LayoutParams(MATCH, 1))
        }
    }

    private fun showAppMenu(app: AppInfo, anchor: View) {
        if (menuView != null) return
        anchor.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val dm = resources.displayMetrics
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)

        val scrim = FrameLayout(this).apply {
            setBackgroundColor(0x55000000)
            setOnClickListener { hideMenu() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            background = GradientDrawable().apply {
                setColor(0xEB2C2C2E.toInt())
                cornerRadius = dp(14).toFloat()
            }
        }
        menuRow(card, "Remover app", 0xFFFF453A.toInt(), false) {
            try {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            } catch (e: Exception) {
            }
        }
        menuRow(card, "Ajustes do launcher", Color.WHITE, true) { showSettings() }

        val cw = (dm.widthPixels * 0.56f).toInt()
        val left = (loc[0] + anchor.width / 2 - cw / 2).coerceIn(dp(12), dm.widthPixels - cw - dp(12))
        val estH = dp(94)
        var topY = loc[1] + anchor.height + dp(30)
        if (topY + estH > dm.heightPixels - dp(130)) topY = loc[1] - estH - dp(8)
        scrim.addView(card, FrameLayout.LayoutParams(cw, WRAP).apply {
            leftMargin = left
            topMargin = topY
        })
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        menuView = scrim
        card.pivotX = cw / 2f
        card.pivotY = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.alpha = 0f
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(120).start()
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideMenu() {
        val m = menuView ?: return
        menuView = null
        m.animate().alpha(0f).setDuration(120).withEndAction { root.removeView(m) }.start()
    }

    // ------------------------------------------------------------ volume

    private val hideVol = Runnable {
        hud.animate().alpha(0f).translationX(-dp(24).toFloat()).setDuration(220)
            .withEndAction { hud.visibility = View.GONE }.start()
    }

    private fun scheduleHideVolume() {
        hud.removeCallbacks(hideVol)
        hud.postDelayed(hideVol, 2000)
    }

    private fun setVolume(p: Float) {
        try {
            val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (p * mx).roundToInt(), 0)
        } catch (e: Exception) {
        }
    }

    private fun showVolume() {
        val mx = max(1, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
        hud.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / mx
        if (hud.visibility != View.VISIBLE) {
            hud.visibility = View.VISIBLE
            hud.alpha = 0f
            hud.translationX = -dp(24).toFloat()
        }
        hud.animate().alpha(1f).translationX(0f).setDuration(200)
            .setInterpolator(DecelerateInterpolator()).start()
        scheduleHideVolume()
    }

    // ------------------------------------------------------------ ajustes

    private fun addPill(parent: LinearLayout, label: String, onClick: () -> Unit): TextView {
        val b = tv(label, 15f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(0x33FFFFFF)
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener { onClick() }
        }
        parent.addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        return b
    }

    private fun showSettings() {
        if (settingsView != null || bootView != null) return
        val scrim = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            alpha = 0f
            setOnClickListener { hideSettings() }
        }
        val r = dp(28).toFloat()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            setPadding(dp(22), dp(22), dp(22), dp(22) + insetBottom)
            background = GradientDrawable().apply {
                setColor(0xF01C1C1E.toInt())
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        card.addView(tv("transparência do dock", 22f, Color.WHITE, true))
        val slider = PillSlider(this, false).apply {
            trackColor = 0x44FFFFFF
            fillColor = Color.WHITE
            progress = dockAlpha
            onChange = { p ->
                dockAlpha = p
                applyAlpha()
            }
        }
        card.addView(slider, LinearLayout.LayoutParams(MATCH, dp(40)).apply { topMargin = dp(16) })
        card.addView(
            tv("de transparente a sólido", 14f, 0xFF8E8E93.toInt()),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        )
        addPill(card, "Testar painel de volume") {
            hideSettings()
            home.postDelayed({ showVolume() }, 250)
        }
        fun bootLabel() = "Teste ao abrir: " + if (prefs.getBoolean("boot", true)) "ligado" else "desligado"
        val bootBtn = addPill(card, bootLabel()) {}
        bootBtn.setOnClickListener {
            prefs.edit().putBoolean("boot", !prefs.getBoolean("boot", true)).apply()
            bootBtn.text = bootLabel()
        }
        addPill(card, "Rever animação de teste") {
            hideSettings()
            runBoot()
        }

        scrim.addView(card, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        settingsView = scrim
        card.translationY = dp(420).toFloat()
        scrim.animate().alpha(1f).setDuration(180).start()
        card.animate().translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideSettings() {
        val s = settingsView ?: return
        settingsView = null
        prefs.edit().putFloat("dockAlpha", dockAlpha).apply()
        (s as ViewGroup).getChildAt(0).animate().translationY(dp(420).toFloat()).setDuration(220).start()
        s.animate().alpha(0f).setDuration(220).withEndAction { root.removeView(s) }.start()
    }

    // ------------------------------------------------------------ animação de abertura (fake speed test)

    private fun runBoot() {
        if (bootView != null) return
        bootShown = true
        home.visibility = View.INVISIBLE
        val v = BootTestView(
            this,
            onReveal = {
                home.visibility = View.VISIBLE
                home.alpha = 0f
                home.scaleX = 1.12f
                home.scaleY = 1.12f
                home.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520)
                    .setInterpolator(DecelerateInterpolator()).start()
            },
            onDone = {
                bootView?.let { root.removeView(it) }
                bootView = null
            }
        )
        bootView = v
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        v.post { v.start() }
    }
}
