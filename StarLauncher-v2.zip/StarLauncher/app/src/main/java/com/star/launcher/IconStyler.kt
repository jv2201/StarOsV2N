package com.star.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

/**
 * Converte qualquer ícone do Android em ícone estilo iOS:
 * quadrado cheio com "squircle" (curva contínua da Apple), pré-renderizado em Bitmap
 * (rápido de desenhar, sem recorte em tempo real).
 */
object IconStyler {
    private var cachedSize = 0
    private var cachedPath: Path? = null

    private fun squircle(size: Int): Path {
        val cp = cachedPath
        if (cp != null && cachedSize == size) return cp
        val p = Path()
        val r = size / 2.0
        val n = 5.0
        val steps = 120
        for (i in 0..steps) {
            val a = 2.0 * PI * i / steps
            val ca = cos(a)
            val sa = sin(a)
            val x = r + r * sign(ca) * abs(ca).pow(2.0 / n)
            val y = r + r * sign(sa) * abs(sa).pow(2.0 / n)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
        cachedPath = p
        cachedSize = size
        return p
    }

    private fun cornersOpaque(b: Bitmap, s: Int): Boolean {
        val m = 2
        return Color.alpha(b.getPixel(m, m)) > 230 &&
            Color.alpha(b.getPixel(s - 1 - m, m)) > 230 &&
            Color.alpha(b.getPixel(m, s - 1 - m)) > 230 &&
            Color.alpha(b.getPixel(s - 1 - m, s - 1 - m)) > 230
    }

    private fun plateColor(b: Bitmap): Int {
        val small = Bitmap.createScaledBitmap(b, 8, 8, true)
        var sum = 0.0
        var wsum = 0.0
        for (y in 0 until 8) for (x in 0 until 8) {
            val c = small.getPixel(x, y)
            val a = Color.alpha(c) / 255.0
            val lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
            sum += lum * a
            wsum += a
        }
        small.recycle()
        val avg = if (wsum > 0.0) sum / wsum else 0.0
        // glifo claro -> fundo escuro; glifo escuro -> fundo claro
        return if (avg > 0.62) 0xFF2C2C2E.toInt() else 0xFFF2F2F7.toInt()
    }

    @Synchronized
    fun render(src: Drawable, size: Int): Bitmap {
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cc = Canvas(content)

        if (Build.VERSION.SDK_INT >= 26 && src is AdaptiveIconDrawable) {
            // desenha as camadas sem a máscara do sistema (círculo etc.)
            val l = (size * 1.5f).toInt()
            val off = -(l - size) / 2
            val bg = src.background
            val fg = src.foreground
            if (bg == null) cc.drawColor(0xFFF2F2F7.toInt())
            if (bg != null) {
                bg.setBounds(off, off, off + l, off + l)
                bg.draw(cc)
            }
            if (fg != null) {
                fg.setBounds(off, off, off + l, off + l)
                fg.draw(cc)
            }
        } else {
            val tmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val tc = Canvas(tmp)
            src.setBounds(0, 0, size, size)
            src.draw(tc)
            if (cornersOpaque(tmp, size)) {
                cc.drawBitmap(tmp, 0f, 0f, null)
            } else {
                cc.drawColor(plateColor(tmp))
                val i = (size * 0.14f).toInt()
                src.setBounds(i, i, size - i, size - i)
                src.draw(cc)
            }
            tmp.recycle()
        }

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawPath(squircle(size), p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(content, 0f, 0f, p)
        content.recycle()
        return out
    }
}
