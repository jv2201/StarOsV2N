package com.star.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import kotlin.math.abs
import kotlin.math.max

/** Slider horizontal em pílula (usado nos ajustes). */
class PillSlider(ctx: Context, private val vertical: Boolean) : View(ctx) {
    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null
    var trackColor: Int = 0x44FFFFFF
    var fillColor: Int = Color.WHITE

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rad = (if (vertical) w else h) / 2f
        rect.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW)
        paint.color = trackColor
        c.drawPath(clip, paint)
        c.save()
        c.clipPath(clip)
        paint.color = fillColor
        if (vertical) c.drawRect(0f, h * (1f - progress), w, h, paint)
        else c.drawRect(0f, 0f, w * progress, h, paint)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (width > 0 && height > 0) {
                    progress = if (vertical) 1f - e.y / height else e.x / width
                    onChange?.invoke(progress)
                }
            }
        }
        return true
    }
}

/** Painel de volume estilo iOS: pílula vertical fina com ícone de alto-falante embaixo. */
class VolumeHud(ctx: Context) : View(ctx) {
    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val clip = Path()
    private val glyph = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(rect, w / 2f, w / 2f, Path.Direction.CW)

        paint.color = 0xB31C1C1E.toInt()
        c.drawPath(clip, paint)
        c.save()
        c.clipPath(clip)
        paint.color = Color.WHITE
        c.drawRect(0f, h * (1f - progress), w, h, paint)
        c.restore()

        // ícone de alto-falante
        val s = w * 0.46f
        val x0 = (w - s) / 2f
        val y0 = h - w * 0.30f - s
        val covered = (y0 + s / 2f) > h * (1f - progress)
        val col = if (covered) 0xFF3A3A3C.toInt() else Color.WHITE
        paint.color = col
        glyph.reset()
        glyph.moveTo(x0 + 0.04f * s, y0 + 0.38f * s)
        glyph.lineTo(x0 + 0.28f * s, y0 + 0.38f * s)
        glyph.lineTo(x0 + 0.52f * s, y0 + 0.16f * s)
        glyph.lineTo(x0 + 0.52f * s, y0 + 0.84f * s)
        glyph.lineTo(x0 + 0.28f * s, y0 + 0.62f * s)
        glyph.lineTo(x0 + 0.04f * s, y0 + 0.62f * s)
        glyph.close()
        c.drawPath(glyph, paint)

        stroke.color = col
        stroke.strokeWidth = s * 0.075f
        if (progress > 0.02f) {
            rect.set(x0 + 0.35f * s, y0 + 0.30f * s, x0 + 0.75f * s, y0 + 0.70f * s)
            c.drawArc(rect, -50f, 100f, false, stroke)
            if (progress > 0.5f) {
                rect.set(x0 + 0.19f * s, y0 + 0.14f * s, x0 + 0.91f * s, y0 + 0.86f * s)
                c.drawArc(rect, -50f, 100f, false, stroke)
            }
        } else {
            c.drawLine(x0 + 0.64f * s, y0 + 0.36f * s, x0 + 0.92f * s, y0 + 0.64f * s, stroke)
            c.drawLine(x0 + 0.92f * s, y0 + 0.36f * s, x0 + 0.64f * s, y0 + 0.64f * s, stroke)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (height > 0) {
                    progress = 1f - e.y / height
                    onChange?.invoke(progress)
                }
            }
        }
        return true
    }
}

/** Bolinhas de página (estilo iOS). */
class DotsView(ctx: Context) : View(ctx) {
    var count: Int = 1
        set(value) {
            field = value
            invalidate()
        }
    var pos: Float = 0f
        set(value) {
            field = value
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(c: Canvas) {
        if (count < 2) return
        val d = resources.displayMetrics.density
        val gap = 14f * d
        val r = 3.5f * d
        val start = (width - gap * (count - 1)) / 2f
        for (i in 0 until count) {
            val near = max(0f, 1f - abs(i - pos))
            paint.alpha = (255f * (0.35f + 0.65f * near)).toInt()
            c.drawCircle(start + i * gap, height / 2f, r, paint)
        }
    }
}

/** Paginador horizontal leve com "snap" de página. */
class SnapPager(ctx: Context) : HorizontalScrollView(ctx) {
    var onScrollPos: ((Float) -> Unit)? = null
    private var startPage = 0
    private var startScroll = 0

    private fun record() {
        val w = width
        if (w > 0) {
            startPage = Math.round(scrollX.toFloat() / w)
            startScroll = scrollX
        }
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) record()
        return super.onInterceptTouchEvent(e)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) record()
        val r = super.onTouchEvent(e)
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) snap()
        return r
    }

    private fun snap() {
        val w = width
        if (w <= 0) return
        val pages = (getChildAt(0) as ViewGroup).childCount
        val d = scrollX - startScroll
        var target = startPage + (if (d > w / 8) 1 else if (d < -w / 8) -1 else 0)
        target = target.coerceIn(0, max(0, pages - 1))
        smoothScrollTo(target * w, 0)
    }

    override fun fling(velocityX: Int) { /* o snap cuida disso */ }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (width > 0) onScrollPos?.invoke(l.toFloat() / width)
    }
}
