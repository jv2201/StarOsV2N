# StarLauncher

Launcher Android inspirado no iOS. Sem dependências externas (APK mínimo).

## Gerar o APK
**Opção A - GitHub (sem PC):** crie um repositório, envie estes arquivos, abra Actions > "Build APK" > Run workflow. Baixe o artefato `StarLauncher-apk` (arquivo .apk dentro do zip).
**Opção B - Android Studio:** File > Open nesta pasta, depois Build > Build APK(s) (variante release).

## Instalar e definir como padrão
Instale o .apk (permita "fontes desconhecidas"), aperte Home e escolha StarLauncher > "Sempre".
